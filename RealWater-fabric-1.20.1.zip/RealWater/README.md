# Real Water — Fabric 1.20.1

Água realista: ondas (geometria + normais), espuma, reflexo do céu, brilho do sol, transparência e
visão de baixo d'água. Menu ⚙ com presets Baixo / Médio / Alto / Ultra.

## Compilar
1. Instale o JDK 17.
2. Abra a pasta no IntelliJ IDEA (importa o Gradle sozinho) e rode a task `build`
   — ou, com Gradle 8.5 instalado: `gradle build`
3. O .jar sai em `build/libs/realwater-1.0.0.jar`. Coloque em `.minecraft/mods`
   junto com o Fabric API 0.92.2+1.20.1.

Para testar direto: `gradle runClient`.

## Usar
- Tecla **G** (em jogo) abre o menu de configurações (muda em Controles).
- Config salva em `config/realwater.json`.

## Compatibilidade
Não funciona com Sodium nem Iris (eles têm renderizador de fluidos/shaders próprios).
