#version 150

#moj_import <realwater.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform vec4 CamPos;
uniform vec4 WaterA;   // altura, espuma, reflexo, transparência
uniform vec4 WaterB;   // qualidade, brilho, chuva, ligado
uniform vec4 SunDir;   // xyz = direção da luz, w = intensidade

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec3 relPos;
in vec3 worldPos;
in vec3 tint;
in vec4 lightCol;
in float isWater;

out vec4 fragColor;

// ---------- ruído de gradiente com derivadas (hash inteiro, sem sin) ----------
vec2 hash22(vec2 p) {
    uvec2 q = uvec2(ivec2(p));
    q = q * uvec2(1597334673u, 3812015801u);
    q = (q.x ^ q.y) * uvec2(1597334673u, 3812015801u);
    return vec2(q) * (1.0 / 4294967295.0) * 2.0 - 1.0;
}

// x = valor, yz = derivada
vec3 gnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    vec2 du = 30.0 * f * f * (f * (f - 2.0) + 1.0);

    vec2 ga = hash22(i + vec2(0.0, 0.0));
    vec2 gb = hash22(i + vec2(1.0, 0.0));
    vec2 gc = hash22(i + vec2(0.0, 1.0));
    vec2 gd = hash22(i + vec2(1.0, 1.0));

    float va = dot(ga, f - vec2(0.0, 0.0));
    float vb = dot(gb, f - vec2(1.0, 0.0));
    float vc = dot(gc, f - vec2(0.0, 1.0));
    float vd = dot(gd, f - vec2(1.0, 1.0));

    float v = va + u.x * (vb - va) + u.y * (vc - va) + u.x * u.y * (va - vb - vc + vd);
    vec2 d = ga + u.x * (gb - ga) + u.y * (gc - ga) + u.x * u.y * (ga - gb - gc + gd)
           + du * (u.yx * (va - vb - vc + vd) + vec2(vb, vc) - va);
    return vec3(v, d);
}

// ondulações pequenas (marolas) que se deslocam em direções diferentes
vec3 ripples(vec2 p, float t, int oct) {
    vec3 acc = vec3(0.0);
    float a = 1.0;
    float f = 0.35;
    for (int i = 0; i < oct; i++) {
        float ang = float(i) * 2.399;
        vec2 drift = vec2(cos(ang), sin(ang)) * t * (0.25 + 0.08 * float(i));
        vec3 n = gnoise(p * f + drift);
        acc.x += a * n.x;
        acc.yz += a * f * n.yz;
        a *= 0.5;
        f *= 2.1;
    }
    return acc;
}

vec4 linear_fog(vec4 inColor, float dist, float fogStart, float fogEnd, vec4 fogColor) {
    if (dist <= fogStart) return inColor;
    float fogValue = dist < fogEnd ? smoothstep(fogStart, fogEnd, dist) : 1.0;
    return vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a);
}

void main() {
    // ----- tudo que não é água (vidro, gelo...) fica igual ao vanilla -----
    if (isWater < 0.5) {
        vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
        fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
        return;
    }

    float t = CamPos.w;
    int q = int(WaterB.x + 0.5);
    float rain = WaterB.z;
    float dist = length(relPos);
    vec3 V = -relPos / max(dist, 1e-4);        // fragmento -> câmera
    vec2 p = worldPos.xz;

    // geometria real da face (para separar topo / lateral / visto de baixo)
    vec3 geoN = normalize(cross(dFdx(relPos), dFdy(relPos)));
    if (dot(geoN, V) < 0.0) geoN = -geoN;
    bool horizontal = abs(geoN.y) > 0.6;
    bool below = horizontal && geoN.y < 0.0;

    vec3 L = SunDir.xyz;
    float sunI = SunDir.w;
    vec3 lit = max(lightCol.rgb, vec3(0.05));

    // ----- ondas grandes + marolas -----
    vec2 g;
    float crest;
    int nw = 4 + min(q, 2);
    float hgt = rw_waves(p, CamPos.w, nw, g, crest);

    int oct = q == 0 ? 2 : (q == 1 ? 3 : (q == 2 ? 5 : 6));
    float detailFade = 1.0 - smoothstep(24.0, 110.0, dist);
    vec3 rip = ripples(p, t, oct);

    vec2 slope = g * WaterA.x * 2.2 + rip.yz * 0.06 * (1.0 + rain) * detailFade;

    vec3 n;
    if (horizontal) {
        n = normalize(vec3(-slope.x, 1.0, -slope.y));
        if (below) n.y = -n.y;
    } else {
        n = geoN;
        crest = 0.0;
    }

    // ----- espuma: cristas + faixas arrastadas por redemoinhos -----
    float foamAmt = 0.0;
    if (horizontal && !below && WaterA.y > 0.01) {
        vec2 warp = vec2(gnoise(p * 0.12 + vec2(t * 0.04, 0.0)).x,
                         gnoise(p * 0.12 + vec2(5.2, 1.3 - t * 0.04)).x) * 3.0;
        vec2 fp = p + warp;
        float streak = 0.5 + 0.5 * gnoise(fp * 0.9 + vec2(t * 0.15, -t * 0.10)).x * 1.4;
        float lace = 0.5 + 0.5 * gnoise(fp * 3.1 - vec2(t * 0.30, t * 0.20)).x * 1.4;
        float cm = smoothstep(0.54, 0.78, crest);
        float pattern = smoothstep(0.30, 0.62, 0.55 * streak + 0.45 * lace);
        foamAmt = cm * (0.35 + 0.65 * pattern) * 1.4 - 0.1;
        foamAmt += 0.35 * smoothstep(0.78, 0.95, streak) * smoothstep(0.45, 0.55, crest);
        foamAmt = clamp(foamAmt * WaterA.y, 0.0, 1.0);
    }

    // ----- cores base (usa a cor do bioma como tom) -----
    vec3 deep = vec3(0.012, 0.11, 0.22);
    vec3 shallow = vec3(0.04, 0.50, 0.58);
    vec3 biome = tint / max(max(tint.r, max(tint.g, tint.b)), 0.001);
    vec3 baseCol = mix(deep, deep * 0.4 + biome * biome * 0.35, 0.5);
    vec3 shallowCol = mix(shallow, biome * 0.6, 0.35);

    // ----- céu refletido -----
    vec3 R = reflect(-V, n);
    R.y = abs(R.y);
    float skyLum = clamp(dot(FogColor.rgb, vec3(0.333)) * 3.0, 0.06, 1.0);
    vec3 horizon = FogColor.rgb;
    vec3 zenith = mix(FogColor.rgb, vec3(0.16, 0.36, 0.85), 0.7) * skyLum;
    zenith = mix(zenith, vec3(dot(zenith, vec3(0.333)) * 0.8), rain * 0.7);
    vec3 sky = mix(horizon, zenith, pow(clamp(R.y, 0.0, 1.0), 0.45));

    vec4 outc;

    if (below) {
        // visto de baixo d'água: janela de Snell + reflexão interna total
        float cosT = clamp(dot(n, V), 0.0, 1.0);
        float window = smoothstep(0.60, 0.74, cosT);
        vec3 skyW = mix(horizon, zenith, 0.6) * 1.1;
        vec3 under = mix(baseCol * 0.7 + shallowCol * 0.12, skyW, window * 0.35);
        under += shallowCol * 0.25 * foamAmt;
        float alpha = mix(0.95, 0.35, window);
        outc = vec4(under * lit, alpha);
    } else {
        float cosV = clamp(dot(n, V), 0.0, 1.0);
        float F = 0.06 + 0.94 * pow(1.0 - cosV, 5.0);
        float Fr = clamp(F * WaterA.z, 0.0, 1.0);

        // espalhamento de luz atravessando as cristas (cor turquesa)
        float sss = pow(clamp(dot(V, -normalize(L + n * 0.35)), 0.0, 1.0), 3.0)
                  * smoothstep(0.35, 0.85, crest) * sunI;
        vec3 body = baseCol * (0.8 + 0.7 * sunI);
        body = mix(body, shallowCol * (0.55 + 0.5 * sunI), cosV * cosV * 0.35 * WaterA.w);
        body += shallowCol * sss * 1.4;

        // brilho do sol
        vec3 H = normalize(L + V);
        float nh = max(dot(n, H), 0.0);
        float spec = pow(nh, 900.0) * 6.0 + pow(nh, 120.0) * 0.6 + pow(nh, 18.0) * 0.05;
        if (q >= 2) {
            float gl = gnoise(p * 9.0 + vec2(t * 0.7, -t * 0.5)).x;
            spec *= 1.0 + 3.0 * smoothstep(0.30, 0.65, gl);
        }
        vec3 sunCol = mix(vec3(1.0, 0.55, 0.28), vec3(1.0, 0.96, 0.88), smoothstep(0.0, 0.45, L.y));
        vec3 specular = sunCol * spec * sunI * (1.0 - rain) * WaterB.y;
        if (!horizontal) specular *= 0.0;

        vec3 col = mix(body, sky, Fr) + specular;

        vec3 foamCol = mix(vec3(0.72, 0.82, 0.90), vec3(1.0), sunI);
        col = mix(col, foamCol, foamAmt);

        float alpha = mix(mix(0.82, 0.38, WaterA.w), 1.0, Fr);
        alpha = mix(alpha, 0.97, foamAmt);
        alpha = clamp(alpha + dot(specular, vec3(0.333)) * 0.6, 0.0, 1.0);
        outc = vec4(col * lit, alpha);
    }

    outc *= ColorModulator;
    fragColor = linear_fog(outc, vertexDistance, FogStart, FogEnd, FogColor);
}
