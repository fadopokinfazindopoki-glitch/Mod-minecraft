// Ondas compartilhadas entre vertex e fragment shader (sem #version aqui).
// xy = direção, z = frequência angular (rad/bloco), w = amplitude (blocos)
const vec4 RW_WAVES[6] = vec4[6](
    vec4( 0.866,  0.500, 0.22, 0.140),
    vec4( 0.259,  0.966, 0.36, 0.090),
    vec4(-0.500,  0.866, 0.55, 0.050),
    vec4( 0.940, -0.342, 0.80, 0.030),
    vec4(-0.766, -0.643, 1.30, 0.018),
    vec4( 0.342,  0.940, 1.90, 0.010)
);
const float RW_MEAN = 0.4658;

// Soma de ondas com crista afiada: h = A * exp(sin(fase) - 1).
// Retorna altura (sem média), g = gradiente em xz, crest = 0..1 (quão perto da crista).
float rw_waves(vec2 p, float t, int count, out vec2 g, out float crest) {
    float h = 0.0;
    float c = 0.0;
    float ampSum = 0.0;
    g = vec2(0.0);
    for (int i = 0; i < count; i++) {
        vec4 w = RW_WAVES[i];
        float ph = dot(w.xy, p) * w.z + t * sqrt(9.8 * w.z);
        float e = exp(sin(ph) - 1.0);
        h += w.w * (e - RW_MEAN);
        g += w.w * e * cos(ph) * w.z * w.xy;
        c += w.w * e;
        ampSum += w.w;
    }
    crest = c / ampSum;
    return h;
}
