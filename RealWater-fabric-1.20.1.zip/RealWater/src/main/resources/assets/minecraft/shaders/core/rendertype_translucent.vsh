#version 150

#moj_import <realwater.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 ChunkOffset;
uniform vec4 CamPos;   // xyz = câmera no mundo, w = tempo animado
uniform vec4 WaterA;   // altura, espuma, reflexo, transparência
uniform vec4 WaterB;   // qualidade, brilho, chuva, ligado

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec3 relPos;
out vec3 worldPos;
out vec3 tint;
out vec4 lightCol;
out float isWater;

void main() {
    vec3 pos = Position;
    float water = 0.0;

    // Água = vértices marcados com alpha 250/255 (ver WaterMarkConsumer)
    if (WaterB.w > 0.5 && abs(Color.a - 250.0 / 255.0) < 0.004) {
        water = 1.0;
        float fy = fract(Position.y);
        if (fy > 0.01 && fy < 0.99) {          // só o topo da superfície se move
            vec2 wxz = Position.xz + ChunkOffset.xz + CamPos.xz;
            vec2 g;
            float cr;
            pos.y += rw_waves(wxz, CamPos.w, 4, g, cr) * WaterA.x;
        }
    }

    vec3 rel = pos + ChunkOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(rel, 1.0);

    vertexDistance = length((ModelViewMat * vec4(rel, 1.0)).xyz);
    lightCol = texelFetch(Sampler2, UV2 / 16, 0);
    vertexColor = Color * lightCol;
    texCoord0 = UV0;
    relPos = rel;
    worldPos = vec3(Position.xz + ChunkOffset.xz + CamPos.xz, 0.0).xzy;
    worldPos.y = Position.y + ChunkOffset.y + CamPos.y;
    tint = Color.rgb;
    isWater = water;
}
