package com.realwater;

import com.realwater.gui.WaterSettingsScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class RealWaterClient implements ClientModInitializer {

    public static final String MOD_ID = "realwater";

    private static KeyBinding openKey;
    private static double animTime = 0.0;
    private static long lastNano = 0L;

    @Override
    public void onInitializeClient() {
        WaterConfig.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.realwater.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.realwater"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                client.setScreen(new WaterSettingsScreen(client.currentScreen));
            }
        });

        WorldRenderEvents.START.register(RealWaterClient::updateUniforms);
    }

    private static void set(ShaderProgram p, String name, float a, float b, float c, float d) {
        GlUniform u = p.getUniform(name);
        if (u != null) u.set(a, b, c, d);
    }

    private static void updateUniforms(WorldRenderContext ctx) {
        ShaderProgram p = GameRenderer.getRenderTypeTranslucentProgram();
        ClientWorld world = ctx.world();
        if (p == null || world == null) return;

        WaterConfig c = WaterConfig.get();
        float td = ctx.tickDelta();

        long now = Util.getMeasuringTimeNano();
        float dt = lastNano == 0L ? 0f : (now - lastNano) / 1.0e9f;
        lastNano = now;
        dt = Math.min(dt, 0.1f);
        animTime = (animTime + dt * c.waveSpeed) % 50000.0;

        Vec3d cam = ctx.camera().getPos();

        // direção do sol / lua
        float a = world.getSkyAngle(td) * MathHelper.TWO_PI;
        float sunY = MathHelper.cos(a);
        Vec3d L = new Vec3d(-MathHelper.sin(a), sunY, 0.25).normalize();
        float intensity;
        if (sunY >= 0f) {
            intensity = MathHelper.clamp(sunY * 3f + 0.15f, 0f, 1f);
        } else {
            L = L.multiply(-1.0);
            intensity = 0.12f;
        }

        set(p, "CamPos", (float) cam.x, (float) cam.y, (float) cam.z, (float) animTime);
        set(p, "WaterA", c.waveHeight, c.foam, c.reflection, c.clarity);
        set(p, "WaterB", c.quality, c.sparkle, world.getRainGradient(td), c.enabled ? 1f : 0f);
        set(p, "SunDir", (float) L.x, (float) L.y, (float) L.z, intensity);
    }
}
