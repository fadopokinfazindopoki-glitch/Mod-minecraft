package com.realwater;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class WaterConfig {

    public enum Preset {
        BAIXO("Baixo"), MEDIO("Médio"), ALTO("Alto"), ULTRA("Ultra"), PERSONALIZADO("Personalizado");

        public final String label;

        Preset(String label) { this.label = label; }

        public Preset next() {
            Preset[] v = values();
            return v[(ordinal() + 1) % v.length];
        }
    }

    public boolean enabled = true;
    public Preset preset = Preset.ULTRA;
    public int quality = 3;            // 0..3 (octavas de detalhe / nº de ondas)
    public float waveHeight = 1.5f;    // 0..3
    public float waveSpeed = 1.1f;     // 0..3
    public float foam = 1.3f;          // 0..2
    public float reflection = 1.1f;    // 0..1.5
    public float clarity = 0.65f;      // 0..1
    public float sparkle = 1.4f;       // 0..2

    private static WaterConfig instance = new WaterConfig();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static WaterConfig get() { return instance; }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("realwater.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                try (Reader r = Files.newBufferedReader(p)) {
                    WaterConfig c = GSON.fromJson(r, WaterConfig.class);
                    if (c != null) {
                        c.quality = Math.max(0, Math.min(3, c.quality));
                        if (c.preset == null) c.preset = Preset.ULTRA;
                        instance = c;
                    }
                }
            } else {
                save();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(path())) {
            GSON.toJson(instance, w);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void applyPreset() {
        switch (preset) {
            case BAIXO:
                quality = 0; waveHeight = 0.7f; waveSpeed = 0.8f; foam = 0.4f; reflection = 0.7f; clarity = 0.5f; sparkle = 0.3f;
                break;
            case MEDIO:
                quality = 1; waveHeight = 1.0f; waveSpeed = 1.0f; foam = 0.8f; reflection = 0.9f; clarity = 0.55f; sparkle = 0.7f;
                break;
            case ALTO:
                quality = 2; waveHeight = 1.2f; waveSpeed = 1.0f; foam = 1.0f; reflection = 1.0f; clarity = 0.6f; sparkle = 1.0f;
                break;
            case ULTRA:
                quality = 3; waveHeight = 1.5f; waveSpeed = 1.1f; foam = 1.3f; reflection = 1.1f; clarity = 0.65f; sparkle = 1.4f;
                break;
            default:
                break;
        }
    }
}
