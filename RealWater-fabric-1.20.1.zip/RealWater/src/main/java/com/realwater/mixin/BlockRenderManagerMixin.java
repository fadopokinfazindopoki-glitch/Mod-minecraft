package com.realwater.mixin;

import com.realwater.WaterMarkConsumer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.BlockRenderManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Marca os vértices da água (alpha = 250/255) para o shader saber o que é água
 * e o que é vidro/gelo/etc. na mesma camada translúcida.
 */
@Mixin(BlockRenderManager.class)
public class BlockRenderManagerMixin {

    @ModifyVariable(method = "renderFluid", at = @At("HEAD"), argsOnly = true)
    private VertexConsumer realwater$markWater(VertexConsumer original) {
        return new WaterMarkConsumer(original);
    }
}
