package com.realwater;

import net.minecraft.client.render.VertexConsumer;

/** Delega tudo ao consumer original, mas força alpha = 250 (marcador de água). */
public class WaterMarkConsumer implements VertexConsumer {
    private static final int MARK = 250;
    private final VertexConsumer d;

    public WaterMarkConsumer(VertexConsumer delegate) { this.d = delegate; }

    @Override public VertexConsumer vertex(double x, double y, double z) { d.vertex(x, y, z); return this; }
    @Override public VertexConsumer color(int r, int g, int b, int a) { d.color(r, g, b, MARK); return this; }
    @Override public VertexConsumer texture(float u, float v) { d.texture(u, v); return this; }
    @Override public VertexConsumer overlay(int u, int v) { d.overlay(u, v); return this; }
    @Override public VertexConsumer light(int u, int v) { d.light(u, v); return this; }
    @Override public VertexConsumer normal(float x, float y, float z) { d.normal(x, y, z); return this; }
    @Override public void next() { d.next(); }
    @Override public void fixedColor(int r, int g, int b, int a) { d.fixedColor(r, g, b, a); }
    @Override public void unfixColor() { d.unfixColor(); }
}
