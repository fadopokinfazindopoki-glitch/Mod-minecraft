package com.realwater.gui;

import com.realwater.WaterConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;

import java.util.Locale;
import java.util.function.Consumer;

public class WaterSettingsScreen extends Screen {

    private static final String[] QUALITY = {"Baixa", "Média", "Alta", "Ultra"};
    private final Screen parent;

    public WaterSettingsScreen(Screen parent) {
        super(Text.literal("⚙ Real Water — Configurações"));
        this.parent = parent;
    }

    private void reopen() {
        this.client.setScreen(new WaterSettingsScreen(parent));
    }

    @Override
    protected void init() {
        WaterConfig c = WaterConfig.get();
        int w = 150, h = 20;
        int left = this.width / 2 - 155, right = this.width / 2 + 5;
        int y = Math.max(32, this.height / 6);
        int step = 24;

        addDrawableChild(ButtonWidget.builder(Text.literal("Efeitos: " + (c.enabled ? "LIGADO" : "DESLIGADO")), b -> {
            c.enabled = !c.enabled;
            reopen();
        }).dimensions(left, y, w, h).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Preset: " + c.preset.label), b -> {
            c.preset = c.preset.next();
            c.applyPreset();
            reopen();
        }).dimensions(right, y, w, h).build());

        y += step;
        addDrawableChild(ButtonWidget.builder(Text.literal("Qualidade: " + QUALITY[c.quality]), b -> {
            c.quality = (c.quality + 1) % 4;
            c.preset = WaterConfig.Preset.PERSONALIZADO;
            reopen();
        }).dimensions(left, y, w, h).build());
        addDrawableChild(new Opt(right, y, w, h, "Altura das ondas", 0f, 3f, c.waveHeight, v -> c.waveHeight = v));

        y += step;
        addDrawableChild(new Opt(left, y, w, h, "Velocidade", 0f, 3f, c.waveSpeed, v -> c.waveSpeed = v));
        addDrawableChild(new Opt(right, y, w, h, "Espuma", 0f, 2f, c.foam, v -> c.foam = v));

        y += step;
        addDrawableChild(new Opt(left, y, w, h, "Reflexo do céu", 0f, 1.5f, c.reflection, v -> c.reflection = v));
        addDrawableChild(new Opt(right, y, w, h, "Transparência", 0f, 1f, c.clarity, v -> c.clarity = v));

        y += step;
        addDrawableChild(new Opt(left, y, w, h, "Brilho do sol", 0f, 2f, c.sparkle, v -> c.sparkle = v));

        addDrawableChild(ButtonWidget.builder(ScreenTexts.DONE, b -> close())
                .dimensions(this.width / 2 - 100, this.height - 28, 200, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 12, 0xFFFFFF);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    @Override
    public void removed() {
        WaterConfig.save();
    }

    private static class Opt extends SliderWidget {
        private final String label;
        private final float min, max;
        private final Consumer<Float> setter;

        Opt(int x, int y, int w, int h, String label, float min, float max, float cur, Consumer<Float> setter) {
            super(x, y, w, h, Text.empty(), (cur - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.setter = setter;
            updateMessage();
        }

        private float real() { return (float) (min + (max - min) * this.value); }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(label + ": " + String.format(Locale.ROOT, "%.2f", real())));
        }

        @Override
        protected void applyValue() {
            setter.accept(real());
            WaterConfig.get().preset = WaterConfig.Preset.PERSONALIZADO;
        }
    }
}
